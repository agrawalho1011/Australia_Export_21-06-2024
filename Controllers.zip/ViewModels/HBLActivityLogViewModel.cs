﻿namespace CanadaExportTrackX.ViewModels
{
    public class HBLActivityLogViewModel
    {
        public string? HBLId { get; set; }
        public string? HBLNumber { get; set; }
        public string? ContainerNo { get; set; }
        public string? ActivityId { get; set; }
        public int? ActivityCount { get; set; }
        public string? FileNo { get; set; }
        public string? StatusId { get; set; }
        public string? Comment { get; set; }
        public DateTime? SI { get; set; }
        public string? UserId { get; set; } = null!;
        public string? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

    }
    public class HBLActivityDataList
    {
        public string Id { get; set; }
        public string FileGuidId { get; set; }
        public string HBLId { get; set; }
        public string Hblno { get; set; }
        public string ActivityId { get; set; }
        public string Activity { get; set; }
        public string? IsDap { get; set; }
        public string CreatedBy { get; set; }
        public string BasedOn { get; set; }
        public string Comment { get; set; }
        public string StatusId { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndDate { get; set; }
        public string UserId { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}
