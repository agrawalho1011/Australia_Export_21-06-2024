﻿namespace CanadaExportTrackX.ViewModels
{
    public class FileActivityLogModel
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string FileId { get; set; }
        public string ActivityId { get; set; }
        public string? ActivityName { get; set; }
        public string StatusId { get; set; }
        public string? StatusName { get; set; }
        public string? Comment { get; set; }
        public string UserId { get; set; }
        public string? UserName { get; set; }
        public string? Roe { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

    }
}
