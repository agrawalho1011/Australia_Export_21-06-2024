﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CanadaExportTrackX.DataModel
{
    public class COBActivity
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string HBLId { get; set; }
        public string? Booking { get; set; }
        public string? USABooking { get; set; }
        public DateTime? ETD { get; set; }
        public string? StatusId { get; set; }
        public string? Comment { get; set; }
        public string? UserId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public virtual StatusMaster Status { get; set; } 

        [ForeignKey("UserId")]
        public virtual ApplicationUser ApplicationUser { get; set; } 
        [ForeignKey("HBLId")]
        public virtual HBLMaster HBLMaster { get; set; }
        public virtual ICollection<COBActivityHistory> COBActivityHistory { get; } = new List<COBActivityHistory>();

    }
}
