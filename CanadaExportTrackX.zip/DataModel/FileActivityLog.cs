﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace CanadaExportTrackX.DataModel
{

    public partial class FileActivityLog
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string ContainerId { get; set; }
        public string? ActivityId { get; set; }
        public string? StatusId { get; set; }
        public string? Comment { get; set; }
        public string? UserId { get; set; }
        public string? Roe { get; set; }
        public int? ActivityCount { get; set; } = 0;
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public virtual ActivityMaster Activity { get; set; } = null!;
        public virtual StatusMaster Status { get; set; } = null!;

        [ForeignKey("UserId")]
        public virtual ApplicationUser ApplicationUser { get; set; } = null!;
        public virtual ICollection<FileAcitivityLogHistory> FileAcitivityLogHistory { get; } = new List<FileAcitivityLogHistory>();
        [ForeignKey("ContainerId")]
        public virtual ContainerMaster ContainerMaster { get; set; } = null!;
    }
}