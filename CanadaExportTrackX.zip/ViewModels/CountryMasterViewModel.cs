﻿namespace CanadaExportTrackX.ViewModels
{
    public class CountryMasterViewModel
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string CountryName { get; set; } = null!;
        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;
    }
}
