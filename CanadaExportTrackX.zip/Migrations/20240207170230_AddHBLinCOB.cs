﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CanadaExportTrackX.Migrations
{
    public partial class AddHBLinCOB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "HBLId",
                table: "COBActivity",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_COBActivity_HBLId",
                table: "COBActivity",
                column: "HBLId");

            migrationBuilder.AddForeignKey(
                name: "FK_COBActivity_HBLMaster_HBLId",
                table: "COBActivity",
                column: "HBLId",
                principalTable: "HBLMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_COBActivity_HBLMaster_HBLId",
                table: "COBActivity");

            migrationBuilder.DropIndex(
                name: "IX_COBActivity_HBLId",
                table: "COBActivity");

            migrationBuilder.DropColumn(
                name: "HBLId",
                table: "COBActivity");
        }
    }
}
